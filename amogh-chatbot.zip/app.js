class AMOGHChatbot {
    constructor() {
        this.platformData = {
            name: "AMOGH Connect",
            tagline: "Connect Innovation with Opportunity - Ever Useful",
            purpose: "A platform where students, PhD holders, professors, and businesses collaborate to transform ideas into real-world impact",
            targetUsers: [
                "Students - Join peer communities & showcase projects",
                "PhD holders - Collaborate on research & funding", 
                "Professors - Share knowledge & mentor next generation",
                "Businesses - Discover solutions & partnerships"
            ],
            contact: {
                email: "amogheveruseful@gmail.com",
                support: "support@amogh.com",
                location: "Connaught Place Delhi-110001"
            },
            statistics: {
                globalCommunities: "150+",
                activeSolutions: "75+",
                co2Reduced: "2.5M tons annually",
                livesImproved: "50M+ people worldwide"
            }
        };

        this.faqDatabase = {
            generalPlatform: [
                {
                    question: "What is AMOGH Connect?",
                    answer: "AMOGH Connect is a collaborative innovation platform where students, PhD holders, professors, and businesses come together to transform ideas into real-world impact. Our tagline is 'Connect Innovation with Opportunity - Ever Useful'.",
                    keywords: ["what", "amogh", "platform", "about", "definition", "info"]
                },
                {
                    question: "Who can use AMOGH Connect?",
                    answer: "Our platform serves four main user groups: <ul><li><strong>Students</strong> who want to join peer communities & showcase projects</li><li><strong>PhD holders</strong> looking to collaborate on research & funding</li><li><strong>Professors</strong> who want to share knowledge & mentor the next generation</li><li><strong>Businesses</strong> seeking to discover solutions & partnerships</li></ul>",
                    keywords: ["who", "users", "target", "audience", "students", "phd", "professors", "businesses"]
                },
                {
                    question: "What makes AMOGH Connect unique?",
                    answer: "We focus on bridging the innovation gap by connecting brilliant minds with real-world opportunities. Our platform emphasizes <span class='highlight'>sustainable future focus</span>, accelerates progress from concept to market, and democratizes innovation for everyone regardless of background or resources.",
                    keywords: ["unique", "special", "different", "innovation", "bridge"]
                }
            ],
            marketplace: [
                {
                    question: "What is the AMOGH marketplace?",
                    answer: "Our marketplace is a global platform for innovation projects and collaboration. You can explore innovative solutions, find projects across categories like <strong>AI & ML</strong>, <strong>Sustainability</strong>, <strong>FinTech</strong>, <strong>HealthTech</strong>, <strong>EdTech</strong>, <strong>IoT</strong>, <strong>Blockchain</strong>, and <strong>Mobile development</strong>.",
                    keywords: ["marketplace", "projects", "collaboration", "solutions", "tell", "about"]
                },
                {
                    question: "How do I find projects on the marketplace?",
                    answer: "You can filter projects by categories (AI & ML, Sustainable, FinTech, etc.), budget range, duration (1-2 weeks to 6+ months), required skills (React, Python, JavaScript, ML, etc.), and minimum rating. Projects are sorted by most recent, highest rated, or price.",
                    keywords: ["find", "filter", "search", "projects", "categories"]
                },
                {
                    question: "What types of projects are available?",
                    answer: "We feature diverse projects including <strong>AI-Based Fraud Detection Systems</strong>, <strong>Online Mental Health Counseling Platforms</strong>, <strong>AI-Powered Chatbots</strong>, <strong>Remote Patient Monitoring Dashboards</strong>, <strong>Personal Finance Trackers</strong>, <strong>Smart City solutions</strong>, and <strong>Virtual Fitness Coaching platforms</strong>.",
                    keywords: ["types", "projects", "available", "examples", "ai", "health", "finance"]
                }
            ],
            sustainableProjects: [
                {
                    question: "What are AMOGH's sustainable projects?",
                    answer: "We focus on eco-friendly solutions including <strong>Solar Community Grid</strong>, <strong>Urban Green Spaces</strong>, <strong>Clean Water Initiative</strong>, <strong>Renewable Energy Hubs</strong>, <strong>Smart Agriculture</strong>, <strong>Waste Management</strong>, <strong>Carbon Capture</strong>, and <strong>Biodiversity Conservation</strong> projects.",
                    keywords: ["sustainable", "eco", "green", "environment", "solar", "clean", "renewable", "info", "projects"]
                },
                {
                    question: "How can I participate in sustainable projects?",
                    answer: "You can join research teams working on sustainable solutions, contribute to projects launching in <span class='highlight'>Winter 2025</span>, and collaborate with professors and students worldwide. We have over 150+ global communities across 6 continents working on 75+ active solutions.",
                    keywords: ["participate", "join", "sustainable", "contribute", "research"]
                },
                {
                    question: "What's the impact of sustainable projects?",
                    answer: "Our projects have <span class='highlight'>reduced 2.5M tons of CO2 annually</span>, <span class='highlight'>improved lives for 50M+ people worldwide</span>, and created lasting environmental impact through innovative eco-friendly technologies.",
                    keywords: ["impact", "results", "co2", "environmental", "lives"]
                }
            ],
            aiAgents: [
                {
                    question: "What are AI Agents on AMOGH?",
                    answer: "AI Agents are autonomous systems that perceive their environment, make decisions, and take actions to achieve specific goals. They combine machine learning, reasoning, and problem-solving capabilities for <strong>business optimization</strong>, <strong>education</strong>, <strong>healthcare</strong>, and <strong>creative industries</strong>.",
                    keywords: ["ai", "agents", "autonomous", "artificial", "intelligence", "ml", "features"]
                },
                {
                    question: "When will the AI Agents marketplace launch?",
                    answer: "The AI Agents marketplace is <span class='highlight'>coming soon with 85% development progress completed</span>. You can get early access by signing up for notifications. The platform will allow you to discover, deploy, and monetize cutting-edge AI solutions.",
                    keywords: ["launch", "when", "ai", "agents", "marketplace", "coming", "soon"]
                },
                {
                    question: "What can AI Agents do?",
                    answer: "AI Agents can <strong>analyze market trends with 95% accuracy</strong>, create personalized education paths, assist in medical diagnosis (reducing errors by 40%), collaborate with creative professionals, provide 24/7 support, and automate complex business processes.",
                    keywords: ["capabilities", "features", "ai", "agents", "can", "do"]
                }
            ],
            consultingServices: [
                {
                    question: "What consulting services does AMOGH offer?",
                    answer: "We provide <strong>AI Agents for business automation</strong>, <strong>R&D services with PhD mentors</strong>, <strong>sustainable development solutions</strong>, <strong>renewable energy technologies</strong>, <strong>custom API development</strong>, and <strong>data analytics & insights</strong> for smarter decision-making.",
                    keywords: ["consulting", "services", "business", "automation", "development"]
                },
                {
                    question: "How can consulting services help my business?",
                    answer: "Our services can <span class='highlight'>boost productivity by up to 300%</span> through AI-powered efficiency, <span class='highlight'>reduce operational costs by up to 60%</span>, provide 24/7 monitoring and threat detection, help achieve <span class='highlight'>80% carbon footprint reduction</span>, and connect you with PhD experts and industry specialists.",
                    keywords: ["help", "business", "benefits", "productivity", "costs", "efficiency"]
                },
                {
                    question: "What industries do you serve?",
                    answer: "We serve diverse industries including <strong>healthcare</strong>, <strong>finance</strong>, <strong>education</strong>, <strong>agriculture</strong>, <strong>manufacturing</strong>, <strong>energy</strong>, <strong>technology</strong>, and more. Our solutions are customized for oil & gas, energy, port development, and various other sectors.",
                    keywords: ["industries", "sectors", "serve", "healthcare", "finance", "energy"]
                }
            ],
            freelancingPhd: [
                {
                    question: "How can I connect with PhD experts?",
                    answer: "Our freelancing platform connects you with world-class PhD scholars for R&D, mentorship, and specialized consulting. We have <strong>2.3k+ Machine Learning experts</strong>, <strong>1.8k+ Data Science experts</strong>, <strong>1.5k+ AI Research experts</strong>, and specialists in various fields.",
                    keywords: ["phd", "experts", "connect", "scholars", "freelancing", "mentorship", "expert", "connection"]
                },
                {
                    question: "What areas do PhD experts cover?",
                    answer: "Our experts specialize in <strong>Machine Learning</strong>, <strong>Data Science</strong>, <strong>AI Research</strong>, <strong>Biotechnology</strong>, <strong>Quantum Computing</strong>, <strong>Blockchain</strong>, <strong>Cybersecurity</strong>, <strong>Robotics</strong>, <strong>Research & Development</strong>, <strong>Academic Mentorship</strong>, <strong>Industry Consulting</strong>, and <strong>Technical Writing</strong>.",
                    keywords: ["areas", "expertise", "specialization", "phd", "machine", "learning", "data", "science"]
                },
                {
                    question: "How does the PhD collaboration process work?",
                    answer: "Simply describe your need, get matched with tailored PhD experts, collaborate securely on our platform with chat and file sharing, track progress, complete your project, and build your professional network. It's <span class='highlight'>free to get started</span>!",
                    keywords: ["process", "collaboration", "how", "work", "steps"]
                }
            ],
            technicalSupport: [
                {
                    question: "How do I get started on AMOGH Connect?",
                    answer: "Getting started is easy: <ol><li><strong>Create your profile</strong> and tell us who you are</li><li><strong>Browse opportunities</strong> that match your skills</li><li><strong>Connect & collaborate</strong> with your dream team</li><li><strong>Launch your project</strong> with our support</li><li><strong>Earn & showcase</strong> your achievements</li></ol>",
                    keywords: ["get", "started", "begin", "start", "how", "steps"]
                },
                {
                    question: "What contact information is available?",
                    answer: `You can reach us at <strong>${this.platformData.contact.support}</strong> for general support, <strong>${this.platformData.contact.email}</strong> for platform inquiries. We're located at <strong>${this.platformData.contact.location}</strong> and offer 24/7 support through our platform.`,
                    keywords: ["contact", "support", "email", "address", "reach"]
                },
                {
                    question: "Is there a mobile app?",
                    answer: "A mobile app is <span class='highlight'>coming soon</span>! We're currently developing mobile applications for better accessibility. You can stay updated by subscribing to our newsletter for announcements about the mobile app launch.",
                    keywords: ["mobile", "app", "application", "phone", "ios", "android"]
                }
            ]
        };

        this.conversationHistory = [];
        this.init();
    }

    init() {
        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setupElements());
        } else {
            this.setupElements();
        }
    }

    setupElements() {
        this.chatMessages = document.getElementById('chatMessages');
        this.messageInput = document.getElementById('messageInput');
        this.sendBtn = document.getElementById('sendBtn');
        this.clearChatBtn = document.getElementById('clearChat');
        this.talkToHumanBtn = document.getElementById('talkToHuman');
        this.quickRepliesContainer = document.getElementById('quickReplies');
        this.typingIndicator = document.getElementById('typingIndicator');

        if (!this.chatMessages) {
            console.error('Chat messages container not found');
            return;
        }

        this.setupEventListeners();
        this.showWelcomeMessage();
    }

    setupEventListeners() {
        // Send button and enter key
        if (this.sendBtn) {
            this.sendBtn.addEventListener('click', () => this.handleSendMessage());
        }
        
        if (this.messageInput) {
            this.messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.handleSendMessage();
                }
            });
        }

        // Header buttons
        if (this.clearChatBtn) {
            this.clearChatBtn.addEventListener('click', () => this.clearChat());
        }
        
        if (this.talkToHumanBtn) {
            this.talkToHumanBtn.addEventListener('click', () => this.talkToHuman());
        }

        // Quick reply buttons - use event delegation
        document.addEventListener('click', (e) => {
            if (e.target.closest('.quick-reply-btn')) {
                const btn = e.target.closest('.quick-reply-btn');
                const query = btn.dataset.query;
                if (query) {
                    this.handleUserMessage(query);
                }
            }
        });

        // Related questions - use event delegation
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('related-question')) {
                e.preventDefault();
                const question = e.target.dataset.question || e.target.textContent;
                this.handleUserMessage(question);
            }
        });
    }

    showWelcomeMessage() {
        const welcomeHtml = `
            <div class="welcome-message">
                <h3>👋 Welcome to AMOGH Connect!</h3>
                <p><strong>${this.platformData.tagline}</strong></p>
                <p>${this.platformData.purpose}</p>
                
                <div class="platform-stats">
                    <div class="stat-item">
                        <span class="stat-number">${this.platformData.statistics.globalCommunities}</span>
                        <div class="stat-label">Global Communities</div>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">${this.platformData.statistics.activeSolutions}</span>
                        <div class="stat-label">Active Solutions</div>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">${this.platformData.statistics.co2Reduced}</span>
                        <div class="stat-label">CO2 Reduced</div>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">${this.platformData.statistics.livesImproved}</span>
                        <div class="stat-label">Lives Improved</div>
                    </div>
                </div>
                
                <p><strong>I'm your AI assistant and I'm here to help you with:</strong></p>
                <ul>
                    <li>Platform information and getting started</li>
                    <li>Marketplace and project discovery</li>
                    <li>Sustainable projects and AI Agents</li>
                    <li>Consulting services and PhD expert connections</li>
                    <li>Technical support and contact information</li>
                </ul>
                
                <p>Feel free to ask me anything or use the quick action buttons below! 🚀</p>
            </div>
        `;

        this.addBotMessage(welcomeHtml);
    }

    handleSendMessage() {
        if (!this.messageInput) return;
        
        const message = this.messageInput.value.trim();
        if (!message) return;

        this.handleUserMessage(message);
        this.messageInput.value = '';
    }

    handleUserMessage(message) {
        this.addUserMessage(message);
        this.hideQuickReplies();
        this.showTypingIndicator();
        
        // Simulate processing time
        setTimeout(() => {
            this.hideTypingIndicator();
            const response = this.processMessage(message);
            this.addBotMessage(response.answer, response.relatedQuestions);
        }, 800 + Math.random() * 1200);
    }

    processMessage(message) {
        const normalizedMessage = message.toLowerCase().trim();
        
        // Search through all FAQ categories
        let bestMatch = null;
        let bestScore = 0;
        let category = '';

        Object.keys(this.faqDatabase).forEach(categoryKey => {
            this.faqDatabase[categoryKey].forEach(faq => {
                const score = this.calculateMatchScore(normalizedMessage, faq);
                if (score > bestScore) {
                    bestScore = score;
                    bestMatch = faq;
                    category = categoryKey;
                }
            });
        });

        if (bestMatch && bestScore > 0.2) {
            const relatedQuestions = this.getRelatedQuestions(category, bestMatch);
            return {
                answer: bestMatch.answer,
                relatedQuestions: relatedQuestions
            };
        }

        return this.getFallbackResponse(normalizedMessage);
    }

    calculateMatchScore(message, faq) {
        let score = 0;
        const messageWords = message.split(/\s+/);
        const keywords = faq.keywords || [];
        
        // Check keyword matches
        keywords.forEach(keyword => {
            if (message.includes(keyword.toLowerCase())) {
                score += 0.4;
            }
        });

        // Check question similarity
        const questionWords = faq.question.toLowerCase().split(/\s+/);
        messageWords.forEach(word => {
            if (word.length > 2 && questionWords.some(qWord => qWord.includes(word) || word.includes(qWord))) {
                score += 0.2;
            }
        });

        return score;
    }

    getRelatedQuestions(category, currentFaq) {
        const categoryFaqs = this.faqDatabase[category] || [];
        return categoryFaqs
            .filter(faq => faq !== currentFaq)
            .slice(0, 3)
            .map(faq => faq.question);
    }

    getFallbackResponse(message) {
        const fallbackResponses = [
            {
                condition: msg => msg.includes('price') || msg.includes('cost') || msg.includes('pricing'),
                answer: "For pricing information and custom quotes, please contact our team at <strong>support@amogh.com</strong>. We offer flexible pricing models based on your specific needs and project requirements.",
                related: ["What consulting services does AMOGH offer?", "How do I get started?", "Contact support"]
            },
            {
                condition: msg => msg.includes('demo') || msg.includes('trial'),
                answer: "Great question! We offer demos and early access to our platform features. You can request a demo by contacting <strong>amogheveruseful@gmail.com</strong> or join our early access program for upcoming features like AI Agents marketplace.",
                related: ["AI Agents features", "How do I get started?", "Contact support"]
            },
            {
                condition: msg => msg.includes('team') || msg.includes('company'),
                answer: "AMOGH Connect is built by a passionate team dedicated to connecting innovation with opportunity. We're based in Connaught Place Delhi-110001 and work with a global network of researchers, developers, and industry experts.",
                related: ["What is AMOGH Connect?", "Contact support", "Consulting services"]
            }
        ];

        const matchedResponse = fallbackResponses.find(response => response.condition(message));
        
        if (matchedResponse) {
            return {
                answer: matchedResponse.answer,
                relatedQuestions: matchedResponse.related
            };
        }

        return {
            answer: `I understand you're asking about "${message}". While I don't have specific information on that topic, I can help you with information about our platform, marketplace, sustainable projects, AI agents, consulting services, and PhD expert connections. 
            
            <p>You can also:</p>
            <ul>
                <li>Contact our support team at <strong>support@amogh.com</strong></li>
                <li>Email us directly at <strong>amogheveruseful@gmail.com</strong></li>
                <li>Try asking about specific platform features</li>
            </ul>
            
            <p>Is there something specific about AMOGH Connect I can help you with?</p>`,
            relatedQuestions: ["What is AMOGH Connect?", "How do I get started?", "Tell me about the marketplace", "Contact support"]
        };
    }

    addUserMessage(message) {
        if (!this.chatMessages) return;

        const messageHtml = `
            <div class="message user">
                <div class="message-bubble">
                    <div class="message-content">${this.escapeHtml(message)}</div>
                </div>
                <div class="message-avatar">
                    <i class="fas fa-user"></i>
                </div>
            </div>
        `;
        
        this.chatMessages.insertAdjacentHTML('beforeend', messageHtml);
        this.scrollToBottom();
        this.conversationHistory.push({ type: 'user', content: message });
    }

    addBotMessage(message, relatedQuestions = []) {
        if (!this.chatMessages) return;

        let relatedHtml = '';
        if (relatedQuestions && relatedQuestions.length > 0) {
            relatedHtml = `
                <div class="related-questions">
                    <h4>Related Questions:</h4>
                    ${relatedQuestions.map(q => `
                        <a href="#" class="related-question" data-question="${this.escapeHtml(q)}">${q}</a>
                    `).join('')}
                </div>
            `;
        }

        const messageHtml = `
            <div class="message bot">
                <div class="message-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="message-bubble">
                    <div class="message-content">${message}</div>
                    ${relatedHtml}
                </div>
            </div>
        `;
        
        this.chatMessages.insertAdjacentHTML('beforeend', messageHtml);
        this.scrollToBottom();
        this.conversationHistory.push({ type: 'bot', content: message });
    }

    showTypingIndicator() {
        if (this.typingIndicator) {
            this.typingIndicator.classList.remove('hidden');
            this.scrollToBottom();
        }
    }

    hideTypingIndicator() {
        if (this.typingIndicator) {
            this.typingIndicator.classList.add('hidden');
        }
    }

    hideQuickReplies() {
        if (this.quickRepliesContainer) {
            this.quickRepliesContainer.classList.add('hidden');
        }
    }

    showQuickReplies() {
        if (this.quickRepliesContainer) {
            this.quickRepliesContainer.classList.remove('hidden');
        }
    }

    clearChat() {
        if (confirm('Are you sure you want to clear the chat history?')) {
            if (this.chatMessages) {
                this.chatMessages.innerHTML = '';
            }
            this.conversationHistory = [];
            this.showQuickReplies();
            this.showWelcomeMessage();
            if (this.messageInput) {
                this.messageInput.focus();
            }
        }
    }

    talkToHuman() {
        const message = `I'd like to connect you with our human support team! Here are the ways to reach us:

        <p><strong>📧 Email Support:</strong></p>
        <ul>
            <li>General Support: <a href="mailto:${this.platformData.contact.support}" target="_blank">${this.platformData.contact.support}</a></li>
            <li>Platform Inquiries: <a href="mailto:${this.platformData.contact.email}" target="_blank">${this.platformData.contact.email}</a></li>
        </ul>
        
        <p><strong>📍 Location:</strong><br>
        ${this.platformData.contact.location}</p>
        
        <p><strong>⏰ Support Hours:</strong><br>
        We provide 24/7 support through our platform and email. Response time is typically within 2-4 hours.</p>
        
        <p>Our human team can help with account setup, technical issues, business partnerships, and any complex queries that need personalized attention!</p>`;

        this.addBotMessage(message, ["How do I get started?", "What consulting services does AMOGH offer?", "What is AMOGH Connect?"]);
    }

    scrollToBottom() {
        if (this.chatMessages) {
            setTimeout(() => {
                this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
            }, 100);
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the chatbot
document.addEventListener('DOMContentLoaded', () => {
    window.amoghChatbot = new AMOGHChatbot();
});

// Also initialize immediately if DOM is already loaded
if (document.readyState !== 'loading') {
    window.amoghChatbot = new AMOGHChatbot();
}